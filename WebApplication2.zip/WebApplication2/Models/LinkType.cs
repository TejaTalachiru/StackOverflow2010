﻿using System;
using System.Collections.Generic;

namespace WebApplication2.Models;

public partial class LinkType
{
    public int Id { get; set; }

    public string Type { get; set; } = null!;
}
