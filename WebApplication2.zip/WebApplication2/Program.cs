using Microsoft.EntityFrameworkCore;
using WebApplication2.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

builder.Services.AddDbContext<StackOverflow2010Context>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("Server=TEJATALACHEERU\\SQLEXPRESS;Database=StackOverflow2010;Trusted_Connection=True;MultipleActiveResultSets=true"), options => options.CommandTimeout(120)));

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "search",
    pattern: "Home/Search",
    defaults: new { controller = "Home", action = "Search" });

app.MapControllerRoute(
    name: "login",
    pattern: "Account/Login",
    defaults: new { controller = "Account", action = "Login" });

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
