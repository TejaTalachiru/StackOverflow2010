﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using WebApplication2.ViewModels;
using System.Threading.Tasks;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class AccountController : Controller
    {
        // GET: /Account/Login
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // POST: /Account/Login
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                
                var isValid = await ValidateCredentialsAsync(model.Username, model.Password);

                if (isValid)
                {
                   
                    await StoreCredentialsAsync(model.Username, model.Password);

                    
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError("", "Invalid username or password.");
                }
            }

            
            return View(model);
        }

        // Validate user credentials (mock implementation for demonstration)
        private Task<bool> ValidateCredentialsAsync(string username, string password)
        {
            
            return Task.FromResult(username == "admin" && password == "admin");
        }

        private Task StoreCredentialsAsync(string username, string password)
        {
           
            return Task.CompletedTask;
        }

        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            
            await ClearStoredCredentialsAsync();

           
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

            
            return RedirectToAction("Login", "Account");
        }

       
        private Task ClearStoredCredentialsAsync()
        {
            
            return Task.CompletedTask;
        }
    }
}
