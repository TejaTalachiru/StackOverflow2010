using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using WebApplication2.Models;
using WebApplication2.ViewModels;

namespace WebApplication2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly StackOverflow2010Context _context;

        public HomeController(ILogger<HomeController> logger, StackOverflow2010Context context)
        {
            _logger = logger;
            _context = context;
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        /*public async Task<IActionResult> Search(string searchTerm, int page = 1)
        {
            int pageSize = 10;

            var postsQuery = _context.Posts
                .Where(p => p.Body.Contains(searchTerm) || (p.Title ?? "").Contains(searchTerm))
                .OrderByDescending(p => p.CreationDate)
                .Select(p => new SearchResultViewModel
                {
                    PostTitle = p.Title ?? "", // Provide a default empty string if p.Title is null
                    DescriptionSnippet = p.Body.Length > 140 ? p.Body.Substring(0, 140) + "..." : p.Body,
                    VotesCount = _context.Votes.Count(v => v.PostId == p.Id),
                    AnswersCount = _context.Posts.Count(a => a.OwnerUserId == p.Id),
                    UserName = _context.Users
                        .Where(u => u.Id == p.OwnerUserId)
                        .Select(u => u.DisplayName)
                        .FirstOrDefault() ?? "", // Provide a default empty string if UserName is null
                    UserReputation = _context.Users
                        .Where(u => u.Id == p.OwnerUserId)
                        .Select(u => u.Reputation)
                        .FirstOrDefault(),
                    Badges = string.Join(", ", _context.Badges.Select(b => b.Name)) // Adjust according to your Badge model Badge model
                });

            var paginatedList = await PaginatedList<SearchResultViewModel>.CreateAsync(postsQuery.AsNoTracking(), page, pageSize);
            return View(paginatedList);
        }*/
        /*public async Task<IActionResult> Index(string searchTerm, int page = 1)
        {
            int pageSize = 10;

            // Optimized query that attempts to minimize the number of database operations
            // by aggregating votes and answers counts in a more efficient manner.
            var postsQuery = from p in _context.Posts
                             where p.Body.Contains(searchTerm) || (p.Title ?? "").Contains(searchTerm)
                             orderby p.CreationDate descending
                             select new
                             {
                                 p.Id,
                                 p.Title,
                                 p.Body,
                                 p.CreationDate,
                                 p.OwnerUserId
                             };

            var postsWithDetails = from p in postsQuery
                                   join v in _context.Votes on p.Id equals v.PostId into pv
                                   from v in pv.DefaultIfEmpty()
                                   join a in _context.Posts on p.Id equals a.ParentId into pa
                                   from a in pa.DefaultIfEmpty()
                                   join u in _context.Users on p.OwnerUserId equals u.Id
                                   select new SearchResultViewModel
                                   {
                                       PostTitle = p.Title ?? "",
                                       DescriptionSnippet = p.Body.Length > 140 ? p.Body.Substring(0, 140) + "..." : p.Body,
                                       VotesCount = pv.Count(),
                                       AnswersCount = pa.Count(),
                                       UserName = u.DisplayName ?? "",
                                       UserReputation = u.Reputation,
                                       // Assuming badges are not essential for search performance, consider loading them separately or optimizing this part further
                                       Badges = "" // Placeholder for badges, consider optimizing
                                   };

            // Pagination applied after the main query to minimize data transfer
            var paginatedList = await PaginatedList<SearchResultViewModel>.CreateAsync(
                postsWithDetails.AsNoTracking(), page, pageSize);

            return View(paginatedList);
        }*/
        public async Task<IActionResult> Index(string searchTerm, int page = 1)
        {
            int pageSize = 10;

            var baseQuery = _context.Posts
                .Where(p => p.Body.Contains(searchTerm) || (p.Title ?? "").Contains(searchTerm))
                .OrderByDescending(p => p.CreationDate);

            var paginatedPosts = await baseQuery
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var searchResults = new List<SearchResultViewModel>();
            foreach (var post in paginatedPosts)
            {
                var votesCount = await _context.Votes.CountAsync(v => v.PostId == post.Id);
                var answersCount = await _context.Posts.CountAsync(a => a.ParentId == post.Id);
                var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == post.OwnerUserId);

                searchResults.Add(new SearchResultViewModel
                {
                    PostTitle = post.Title ?? "",
                    DescriptionSnippet = post.Body.Length > 140 ? post.Body.Substring(0, 140) + "..." : post.Body,
                    VotesCount = votesCount,
                    AnswersCount = answersCount,
                    UserName = user?.DisplayName ?? "",
                    UserReputation = user?.Reputation ?? 0,
                    Badges = "" // Consider fetching badges if needed
                });
            }

            // Count total number of posts matching the search term
            var totalCount = await baseQuery.CountAsync();

            // Create PaginatedList
            var paginatedList = new PaginatedList<SearchResultViewModel>(searchResults, totalCount, page, pageSize);

            return View(paginatedList);
        }





    }
}
