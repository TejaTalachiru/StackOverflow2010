
function storeCredentials(username, password) {
    if ('credentials' in navigator) {
        navigator.credentials.store(new PasswordCredential({
            id: username,
            password: password
        })).then(() => {
            console.log('Credentials stored successfully.');
        }).catch((error) => {
            console.error('Error storing credentials:', error);
        });
    } else {
        console.error('Credential Management API is not supported in this browser.');
    }
}


window.onload = async function () {
    if ('credentials' in navigator) {
        navigator.credentials.get({
            password: true,
            mediation: 'optional'
        }).then(credentials => {
            if (credentials instanceof PasswordCredential) {
                document.getElementById('username').value = credentials.id;
                document.getElementById('password').value = credentials.password;
            }
        }).catch((error) => {
            console.error('Error retrieving credentials:', error);
        });
    }
};


function clearStoredCredentials() {
    if ('credentials' in navigator) {
        navigator.credentials.preventSilentAccess().then(() => {
            console.log('Stored credentials cleared successfully.');
        }).catch((error) => {
            console.error('Error clearing stored credentials:', error);
        });
    } else {
        console.error('Credential Management API is not supported in this browser.');
    }
}
