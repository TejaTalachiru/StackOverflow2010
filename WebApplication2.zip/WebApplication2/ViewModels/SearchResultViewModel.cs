﻿namespace WebApplication2.ViewModels
{
    public class SearchResultViewModel
    {
        public string PostTitle { get; set; }
        public string DescriptionSnippet { get; set; } 
        public int VotesCount { get; set; }
        public int AnswersCount { get; set; }
        public string UserName { get; set; }
        public int UserReputation { get; set; }
        public string Badges { get; set; }
    }
    
}
